# Fetch and filter from OddsAPI
