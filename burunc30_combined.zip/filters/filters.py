# All 5 filters applied to both sources
