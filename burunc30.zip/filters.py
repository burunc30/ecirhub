import aiohttp
from config import ODDS_API_KEY

async def fetch_odds():
    url = f"https://api.the-odds-api.com/v4/sports/soccer/odds/?regions=eu&markets=h2h,draw_no_bet,halftime_fulltime&apiKey={ODDS_API_KEY}"
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            return await resp.json()

def check_filters(game, bookmaker_key="bet365"):
    try:
        bookie_data = next(b for b in game["bookmakers"] if b["key"] == bookmaker_key)
        markets = {m["key"]: m for m in bookie_data["markets"]}

        h2h = markets.get("h2h", {}).get("outcomes", [])
        dnb = markets.get("draw_no_bet", {}).get("outcomes", [])
        htft = markets.get("halftime_fulltime", {}).get("outcomes", [])

        home = h2h[0] if len(h2h) >= 1 else {}
        away = h2h[1] if len(h2h) >= 2 else {}

        if home.get("price", 0) > 2.0:
            return True
    except Exception:
        pass
    return False

async def get_filtered_matches(include_all=False):
    data = await fetch_odds()
    results = []
    for game in data:
        if include_all or check_filters(game):
            results.append(f"<b>{game['home_team']} vs {game['away_team']}</b>\nBaşlama vaxtı: {game['commence_time']}")
    return results