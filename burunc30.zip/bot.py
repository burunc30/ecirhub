import asyncio
from filters import get_filtered_matches
from config import TELEGRAM_CHAT_ID, TELEGRAM_BOT_TOKEN
import aiohttp

async def send_telegram_message(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": message, "parse_mode": "HTML"}
    async with aiohttp.ClientSession() as session:
        async with session.post(url, data=payload) as resp:
            return await resp.text()

async def main():
    matches = await get_filtered_matches()
    if matches:
        msg = "\n\n".join(matches)
    else:
        msg = "Uyğun oyun yoxdur, amma əmsallar bunlardır:\n\n" + "\n\n".join(await get_filtered_matches(include_all=True))
    await send_telegram_message(msg)

if __name__ == "__main__":
    asyncio.run(main())