
import os
import requests
from dotenv import load_dotenv

load_dotenv()

ODDS_API_KEY = os.getenv("ODDS_API_KEY")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

def send_message(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": message}
    requests.post(url, data=payload)

def get_odds():
    url = f"https://api.the-odds-api.com/v4/sports/soccer/odds/?apiKey={ODDS_API_KEY}&regions=eu&markets=h2h,draw_no_bet,over_under_2.5,btts,half_time_full_time&oddsFormat=decimal"
    res = requests.get(url)
    if res.status_code == 200:
        data = res.json()
        filtered = []
        for match in data:
            league = match.get("sport_title", "")
            if not any(top in league.lower() for top in ["england", "spain", "italy", "france", "germany", "champions", "conference"]):
                filtered.append(match)
        for match in filtered[:10]:
            home = match['home_team']
            away = match['away_team']
            time = match['commence_time']
            send_message(f"{time} - {home} vs {away}")
    else:
        send_message(f"API error: {res.status_code}")

if __name__ == "__main__":
    send_message("Bot started.")
    get_odds()
