import requests

def send_message(text):
    TOKEN = "6493018922:AAHf_ErZB0SYayD6N5VZx-xswZ4c6BoS0uM"
    CHAT_ID = "1488455191"
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    payload = {"chat_id": CHAT_ID, "text": text, "parse_mode": "HTML"}
    requests.post(url, data=payload)
