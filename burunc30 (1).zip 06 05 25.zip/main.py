from bot import send_message
from leagues import get_matches

def main():
    matches = get_matches()
    if not matches:
        send_message("Uygun oyun yoxdur.")
    else:
        message = "\n\n".join(matches)
        send_message(f"<b>Uyğun oyunlar:</b>\n\n{message}")

if __name__ == "__main__":
    main()
