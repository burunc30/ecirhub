def get_matches():
    # Burada filtrə uyğun gələn test matçları qaytarılır
    return [
        "Team A vs Team B\n1X2: 2.35 - 3.10 - 2.80",
        "Team C vs Team D\n1X2: 2.05 - 3.20 - 3.50"
    ]
